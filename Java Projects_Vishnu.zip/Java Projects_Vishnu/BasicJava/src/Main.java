// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    static String word;
      static int Agecheck(int age) {

         if (age > 18) {
           word = "has Access granted to vote";


         } else if (age < 18) {
             System.out.print("Age not eligible to vote");
         }
         return age;

     }
     static String NameAgecheck(String name){

       return name;

    }



        public static void main(String[] args) {
           Agecheck(34);
          System.out.println(NameAgecheck ("Siddharth") +" "+ word);


            // Press Alt+Enter with your caret at the highlighted text to see how
            // IntelliJ IDEA suggests fixing it.


        }
        }

