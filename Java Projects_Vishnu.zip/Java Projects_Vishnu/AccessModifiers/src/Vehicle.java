import java.util.Scanner;
public class Vehicle {
    public static String carbrandname;

    public String vehiclebrand;




    public void honk(){
        String sound = "Peep Peep";
        System.out.println(sound);
    }
    static class Car extends Vehicle{

        public static String carname;

    }
    public static void main(String[] args) {

        Vehicle.Car myCar = new Vehicle.Car();
        myCar.honk();

        Scanner obj = new Scanner(System.in);
        System.out.println("Enter Vehiclename");
        String vehiclebrand =obj.nextLine();
        System.out.println("Vehiclebrand is " + vehiclebrand);

        System.out.println("Enter carname");
        String carname = obj.nextLine();
        System.out.println("carname is " + carname);


         System.out.println("Car is: " + vehiclebrand + " " + carname);


    }


}


