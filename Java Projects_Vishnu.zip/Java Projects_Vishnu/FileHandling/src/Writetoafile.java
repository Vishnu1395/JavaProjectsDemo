import java.io.FileWriter;
import java.io.IOException;
  public class Writetoafile {
        public static void main(String[] args) {
            try {
                FileWriter myWriter = new FileWriter("C:\\Users\\vishn\\Documents\\JavaFilehandling\\filename.txt");
                myWriter.write("It's easy and fun once you learn coding!");
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }

