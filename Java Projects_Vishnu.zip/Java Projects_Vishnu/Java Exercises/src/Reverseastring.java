public class Reverseastring {

    public static void main (String[] args) {

        String str = "Hello";
        String reversedstr = "";
        System.out.println("Original String is : "+ str);

        for (int i = 0; i < str.length(); i++) {

            reversedstr = str.charAt(i) + reversedstr;

        }
        System.out.println("Reversed String is " + reversedstr);
    }

}
