import java.util.StringTokenizer;
public class Stringtokenexample {

    // Function to count total number of words in the string
    public static int
    countWords(String str)
    {
        if (str == null || str.isEmpty())
            return 0;
       StringTokenizer tokens = new StringTokenizer(str);
       return tokens.countTokens();
    }

    public static void main(String args[]) {

        // Given String str
        String str = "Hardwork with consistency and discipline never fails";

        // Print the result
        System.out.println("No of words are : " +countWords(str));
    }
}