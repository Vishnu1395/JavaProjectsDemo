import java.util.Scanner;
public class Palindrome {

    public static void main(String[] args){

                String reversestring ="";

        Scanner obj = new Scanner(System.in);
        System.out.println("Enter the String");

        String originalstring = obj.nextLine();
        System.out.println("The String entered is :" + originalstring);

        for(int i=0; i< originalstring.length(); i++) {
            reversestring = originalstring.charAt(i) + reversestring;
        }

        System.out.println("The reverse String is: " + reversestring);
        if( reversestring.equals(originalstring)){
            System.out.println("The string is a Palindrome");

        }else {

            System.out.println("The String is not a Palindrome");


        }
    }
}
