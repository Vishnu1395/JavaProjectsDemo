public class Sumofelements {
    static int[] myArray = {1, 5, 10, 25};
    static int sum = 0;
    static int i;

    public static void main(String[] args) {


// Loop through the array elements and store the sum in the sum variable
        for (i = 0; i < myArray.length; i++) {
            sum += myArray[i];
        }

        System.out.println("The sum is: " + sum);
    }
}
